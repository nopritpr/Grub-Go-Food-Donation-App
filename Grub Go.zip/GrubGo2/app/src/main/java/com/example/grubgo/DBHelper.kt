package com.example.grubgo

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper private constructor(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "FoodDonationDB"
        private const val DATABASE_VERSION = 2

        // Table Name
        const val TABLE_DONATIONS = "Donations"

        // Column Names
        const val COLUMN_ID = "id"
        const val COLUMN_DONOR_NAME = "donor_name"
        const val COLUMN_CONTACT = "contact"
        const val COLUMN_FOOD_ITEM = "food_item"
        const val COLUMN_QUANTITY = "quantity"
        const val COLUMN_UNIT = "unit"
        const val COLUMN_EXPIRY = "expiry"
        const val COLUMN_WHEN_MADE = "when_made"
        const val COLUMN_ADDRESS = "address"
        const val COLUMN_IMAGE_URIS = "image_uris"
        const val COLUMN_STATUS = "status" // New column for donation status

        @Volatile
        private var INSTANCE: DBHelper? = null

        fun getInstance(context: Context): DBHelper {
            return INSTANCE ?: synchronized(this) {
                val instance = DBHelper(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTableQuery = """
            CREATE TABLE $TABLE_DONATIONS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_DONOR_NAME TEXT NOT NULL,
                $COLUMN_CONTACT TEXT NOT NULL,
                $COLUMN_FOOD_ITEM TEXT NOT NULL,
                $COLUMN_QUANTITY TEXT NOT NULL,
                $COLUMN_UNIT TEXT NOT NULL,
                $COLUMN_EXPIRY TEXT NOT NULL,
                $COLUMN_WHEN_MADE TEXT NOT NULL,
                $COLUMN_ADDRESS TEXT NOT NULL,
                $COLUMN_IMAGE_URIS TEXT,
                $COLUMN_STATUS TEXT NOT NULL DEFAULT 'Available'
            )
        """
        db?.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db?.execSQL("ALTER TABLE $TABLE_DONATIONS ADD COLUMN $COLUMN_STATUS TEXT NOT NULL DEFAULT 'Available'")
        }
    }

    // Insert a new donation
    fun insertDonation(
        donorName: String,
        contact: String,
        foodItem: String,
        quantity: String,
        unit: String,
        expiry: String,
        whenMade: String,
        address: String,
        imageUris: List<String>
    ): Long {
        val db = writableDatabase
        val contentValues = ContentValues().apply {
            put(COLUMN_DONOR_NAME, donorName)
            put(COLUMN_CONTACT, contact)
            put(COLUMN_FOOD_ITEM, foodItem)
            put(COLUMN_QUANTITY, quantity)
            put(COLUMN_UNIT, unit)
            put(COLUMN_EXPIRY, expiry)
            put(COLUMN_WHEN_MADE, whenMade)
            put(COLUMN_ADDRESS, address)
            put(COLUMN_IMAGE_URIS, imageUris.joinToString(","))
            put(COLUMN_STATUS, "Available")
        }
        val rowId = db.insert(TABLE_DONATIONS, null, contentValues)
        db.close()
        return rowId
    }

    // Retrieve available donations
    fun getAvailableDonations(): List<Donation> {
        val donationList = mutableListOf<Donation>()
        val db = readableDatabase
        val cursor: Cursor = db.rawQuery("SELECT * FROM $TABLE_DONATIONS WHERE $COLUMN_STATUS = 'Available'", null)
        cursor.use {
            while (it.moveToNext()) {
                val donation = Donation(
                    id = it.getInt(it.getColumnIndexOrThrow(COLUMN_ID)),
                    donorName = it.getString(it.getColumnIndexOrThrow(COLUMN_DONOR_NAME)),
                    contact = it.getString(it.getColumnIndexOrThrow(COLUMN_CONTACT)),
                    foodItem = it.getString(it.getColumnIndexOrThrow(COLUMN_FOOD_ITEM)),
                    quantity = it.getString(it.getColumnIndexOrThrow(COLUMN_QUANTITY)),
                    unit = it.getString(it.getColumnIndexOrThrow(COLUMN_UNIT)),
                    expiry = it.getString(it.getColumnIndexOrThrow(COLUMN_EXPIRY)),
                    whenMade = it.getString(it.getColumnIndexOrThrow(COLUMN_WHEN_MADE)),
                    address = it.getString(it.getColumnIndexOrThrow(COLUMN_ADDRESS)),
                    imageUris = it.getString(it.getColumnIndexOrThrow(COLUMN_IMAGE_URIS)).split(","),
                    status = it.getString(it.getColumnIndexOrThrow(COLUMN_STATUS))
                )
                donationList.add(donation)
            }
        }
        db.close()
        return donationList
    }

    // Mark a donation as completed
    fun markAsCompleted(donationId: Int) {
        val db = writableDatabase
        val contentValues = ContentValues().apply {
            put(COLUMN_STATUS, "Completed")
        }
        db.update(TABLE_DONATIONS, contentValues, "$COLUMN_ID = ?", arrayOf(donationId.toString()))
        db.close()
    }

    // Clear all donations
    fun clearAllDonations() {
        val db = writableDatabase
        db.execSQL("DELETE FROM $TABLE_DONATIONS")
        db.close()
    }

    // Data class for Donation
    data class Donation(
        val id: Int,
        val donorName: String,
        val contact: String,
        val foodItem: String,
        val quantity: String,
        val unit: String,
        val expiry: String,
        val whenMade: String,
        val address: String,
        val imageUris: List<String>,
        val status: String
    )
}
