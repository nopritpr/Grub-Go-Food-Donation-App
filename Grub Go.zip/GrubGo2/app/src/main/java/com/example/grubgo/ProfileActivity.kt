package com.example.grubgo

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayOutputStream

class ProfileActivity : AppCompatActivity() {

    private lateinit var etProfileName: EditText
    private lateinit var etProfileNumber: EditText
    private lateinit var etProfileEmail: EditText
    private lateinit var btnSaveProfile: Button
    private lateinit var btnChangeProfilePicture: Button
    private lateinit var ivProfilePicture: ImageView
    private lateinit var sharedPreferences: SharedPreferences

    private val PICK_IMAGE_REQUEST = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Initialize views
        etProfileName = findViewById(R.id.etProfileName)
        etProfileNumber = findViewById(R.id.etProfileNumber)
        etProfileEmail = findViewById(R.id.etProfileEmail)
        btnSaveProfile = findViewById(R.id.btnSaveProfile)
        btnChangeProfilePicture = findViewById(R.id.btnChangeProfilePicture)
        ivProfilePicture = findViewById(R.id.ivProfilePicture)

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("UserProfile", MODE_PRIVATE)

        // Load saved profile data
        loadProfileData()

        // Save profile data on button click
        btnSaveProfile.setOnClickListener {
            saveProfileData()
        }

        // Change profile picture
        btnChangeProfilePicture.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, PICK_IMAGE_REQUEST)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            val imageUri: Uri? = data.data
            try {
                val bitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, imageUri)
                ivProfilePicture.setImageBitmap(bitmap)

                // Save the profile picture as a Base64 string
                val outputStream = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                val imageBase64 = Base64.encodeToString(outputStream.toByteArray(), Base64.DEFAULT)
                sharedPreferences.edit().putString("profilePicture", imageBase64).apply()

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Load profile data from SharedPreferences
    private fun loadProfileData() {
        val name = sharedPreferences.getString("name", "")
        val number = sharedPreferences.getString("number", "")
        val email = sharedPreferences.getString("email", "")
        val profilePictureBase64 = sharedPreferences.getString("profilePicture", null)

        etProfileName.setText(name)
        etProfileNumber.setText(number)
        etProfileEmail.setText(email)

        // Load profile picture
        if (profilePictureBase64 != null) {
            val decodedBytes = Base64.decode(profilePictureBase64, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
            ivProfilePicture.setImageBitmap(bitmap)
        }
    }
    // Save profile data to SharedPreferences
    private fun saveProfileData() {
        val name = etProfileName.text.toString()
        val number = etProfileNumber.text.toString()
        val email = etProfileEmail.text.toString()

        if (name.isEmpty() || number.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
        } else {
            val editor = sharedPreferences.edit()
            editor.putString("name", name)
            editor.putString("number", number)
            editor.putString("email", email)
            editor.apply()

            Toast.makeText(this, "Profile updated successfully", Toast.LENGTH_SHORT).show()

            // Navigate back to the previous page
            finish()
        }
    }

}
