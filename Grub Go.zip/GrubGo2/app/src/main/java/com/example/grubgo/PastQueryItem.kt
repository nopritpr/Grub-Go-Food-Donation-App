package com.example.grubgo.models

data class PastQueryItem(
    val description: String,
    val contactInfo: String,
    var resolved: Boolean
)
