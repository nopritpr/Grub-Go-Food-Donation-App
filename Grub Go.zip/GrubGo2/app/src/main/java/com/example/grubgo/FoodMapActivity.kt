package com.example.grubgo

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.mapbox.geojson.Point
import com.mapbox.maps.CameraOptions
import com.mapbox.maps.MapView
import com.mapbox.maps.Style
import com.mapbox.maps.plugin.LocationPuck2D
import com.mapbox.maps.plugin.gestures.OnMoveListener
import com.mapbox.maps.plugin.gestures.gestures
import com.mapbox.maps.plugin.locationcomponent.OnIndicatorBearingChangedListener
import com.mapbox.maps.plugin.locationcomponent.OnIndicatorPositionChangedListener
import com.mapbox.maps.plugin.locationcomponent.location

class FoodMapActivity : AppCompatActivity() {

    private lateinit var mapView: MapView
    private lateinit var floatingActionButton: FloatingActionButton

    private val activityResultLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { result: Boolean ->
        if (result) {
            Toast.makeText(this, "Permission granted!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Location permission denied.", Toast.LENGTH_SHORT).show()
        }
    }

    private val onIndicatorBearingChangedListener = OnIndicatorBearingChangedListener { bearing ->
        mapView.getMapboxMap().setCamera(CameraOptions.Builder().bearing(bearing).build())
    }

    private val onIndicatorPositionChangedListener = OnIndicatorPositionChangedListener { point ->
        mapView.getMapboxMap().setCamera(
            CameraOptions.Builder()
                .center(point)
                .zoom(20.0)
                .build()
        )
    }

    private val onMoveListener = object : OnMoveListener {
        override fun onMoveBegin(detector: com.mapbox.android.gestures.MoveGestureDetector) {
            val locationComponent = mapView.location
            locationComponent.removeOnIndicatorBearingChangedListener(onIndicatorBearingChangedListener)
            locationComponent.removeOnIndicatorPositionChangedListener(onIndicatorPositionChangedListener)
            mapView.gestures.removeOnMoveListener(this)
            floatingActionButton.show()
        }

        override fun onMove(detector: com.mapbox.android.gestures.MoveGestureDetector): Boolean {
            return false
        }

        override fun onMoveEnd(detector: com.mapbox.android.gestures.MoveGestureDetector) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mapView = findViewById(R.id.mapView)
        floatingActionButton = findViewById(R.id.focusLocation)

        // Request Location Permission
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            activityResultLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        floatingActionButton.hide()
        mapView.getMapboxMap().loadStyleUri(Style.SATELLITE) { style ->
            mapView.getMapboxMap().setCamera(CameraOptions.Builder().zoom(20.0).build())
            val locationComponentPlugin = mapView.location

            locationComponentPlugin.updateSettings {
                enabled = true
            }

            // Default Blue Dot Location Puck
            val locationPuck = LocationPuck2D() // Default Location Puck without custom images
            locationComponentPlugin.locationPuck = locationPuck

            locationComponentPlugin.addOnIndicatorBearingChangedListener(onIndicatorBearingChangedListener)
            locationComponentPlugin.addOnIndicatorPositionChangedListener(onIndicatorPositionChangedListener)
            mapView.gestures.addOnMoveListener(onMoveListener)

            floatingActionButton.setOnClickListener {
                locationComponentPlugin.addOnIndicatorBearingChangedListener(onIndicatorBearingChangedListener)
                locationComponentPlugin.addOnIndicatorPositionChangedListener(onIndicatorPositionChangedListener)
                mapView.gestures.addOnMoveListener(onMoveListener)
                floatingActionButton.hide()
            }
        }
    }
}
