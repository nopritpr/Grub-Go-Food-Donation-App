package com.example.grubgo.models

data class FaqItem(val question: String, val answer: String)
