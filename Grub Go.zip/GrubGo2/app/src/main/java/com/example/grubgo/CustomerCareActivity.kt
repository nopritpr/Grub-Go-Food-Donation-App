package com.example.grubgo

import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.grubgo.adapters.FaqAdapter
import com.example.grubgo.adapters.PastQueryAdapter
import com.example.grubgo.models.FaqItem
import com.example.grubgo.models.PastQueryItem

class CustomerCareActivity : AppCompatActivity() {

    private lateinit var rvFaqList: RecyclerView
    private lateinit var rvPastQueries: RecyclerView
    private lateinit var btnQueryForm: Button
    private lateinit var btnPastQueries: Button
    private lateinit var llQueryForm: LinearLayout
    private lateinit var llPastQueries: LinearLayout
    private lateinit var etQueryDescription: EditText
    private lateinit var etContactInfo: EditText
    private lateinit var spContactMode: Spinner
    private lateinit var btnSubmitQuery: Button
    private lateinit var btnDeleteAllQueries: Button

    private val pastQueries = mutableListOf<PastQueryItem>()
    private lateinit var pastQueryAdapter: PastQueryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.customercare)

        // Initialize views
        rvFaqList = findViewById(R.id.rvFaqList)
        rvPastQueries = findViewById(R.id.rvPastQueries)
        btnQueryForm = findViewById(R.id.btnQueryForm)
        btnPastQueries = findViewById(R.id.btnPastQueries)
        llQueryForm = findViewById(R.id.llQueryForm)
        llPastQueries = findViewById(R.id.llPastQueries)
        etQueryDescription = findViewById(R.id.etQueryDescription)
        etContactInfo = findViewById(R.id.etContactInfo)
        spContactMode = findViewById(R.id.spContactMode)
        btnSubmitQuery = findViewById(R.id.btnSubmitQuery)
        btnDeleteAllQueries = findViewById(R.id.btnDeleteAllQueries)

        // Setup RecyclerViews
        rvFaqList.layoutManager = LinearLayoutManager(this)
        rvFaqList.adapter = FaqAdapter(getFaqList())

        pastQueryAdapter = PastQueryAdapter(pastQueries) { action, position ->
            handlePastQueryAction(action, position)
        }
        rvPastQueries.layoutManager = LinearLayoutManager(this)
        rvPastQueries.adapter = pastQueryAdapter

        // Populate Spinner
        val contactModes = arrayOf("Email", "Phone")
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, contactModes)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spContactMode.adapter = spinnerAdapter

        // Button actions
        btnQueryForm.setOnClickListener {
            llQueryForm.visibility = if (llQueryForm.visibility == View.GONE) View.VISIBLE else View.GONE
            llPastQueries.visibility = View.GONE
        }

        btnPastQueries.setOnClickListener {
            llPastQueries.visibility = if (llPastQueries.visibility == View.GONE) View.VISIBLE else View.GONE
            llQueryForm.visibility = View.GONE
        }

        btnSubmitQuery.setOnClickListener {
            submitQuery()
        }

        btnDeleteAllQueries.setOnClickListener {
            deleteAllQueries()
        }
    }

    private fun getFaqList(): List<FaqItem> {
        return listOf(
            FaqItem("What is this app?", "This app is designed to connect food donors with those in need. It facilitates food donations by allowing donors to list items and enabling receivers to view and accept those donations. The app also provides a map to locate donors and keeps track of all activities."),
            FaqItem("How do I submit a query?", "To submit a query, navigate to the 'Customer Care' section, select your preferred mode of contact (Email or Phone), and describe your issue or question in detail. Submit the form, and our team will get back to you promptly."),
            FaqItem("What is the contact mode?", "The app allows you to contact our support team through Email or Phone. Choose the option that is most convenient for you to get help or answers to your queries."),
            FaqItem("How do I donate food using this app?", "To donate food, go to the 'Donate' section from the dashboard. Fill out the details, including the type of food, quantity, and pickup location, and submit your donation. Once submitted, your donation will be visible to nearby receivers, who can request it."),
            FaqItem("Who can receive the food donations?", "Any user registered as a receiver on the app can view and request available donations in their vicinity. The app ensures that receivers see only relevant listings based on their location."),
            FaqItem("What information do I need to provide when donating food?", "When donating food, you need to specify the type (e.g., cooked, non-perishable), quantity, expiration date (if applicable), and the pickup location. Providing these details helps receivers make informed choices and ensures transparency."),
            FaqItem("How can I view my previous donations or received items?", "You can view all your past activities in the 'History' section. It keeps a detailed record of every donation you’ve made or received, including dates, food types, and quantities."),
            FaqItem("How does the map feature work?", "The 'Food Map' feature shows all active donors as green points. You can tap on a point to see the donor's details, including the food type, quantity, and location, making it easier to coordinate pickup."),
            FaqItem("What happens after I request a donation?", "After you request a donation, the donor is notified. If they approve your request, the app will provide you with their contact details and pickup information. You can then arrange to collect the food."),
            FaqItem("Can I edit or cancel my donation after listing it?", "Yes, you can manage your donation by going to the 'History' section. Select the specific donation to either edit its details (e.g., quantity, location) or cancel it if it's no longer available."),
            FaqItem("How is the privacy of my location maintained?", "The app ensures your privacy by only displaying a general location on the Food Map. Your exact address is shared only with verified receivers once they request your donation and you approve."),
            FaqItem("What types of food can I donate?", "You can donate both perishable and non-perishable food items, such as cooked meals, groceries, or packaged foods. Ensure all items are safe, hygienic, and within their expiration date."),
            FaqItem("Can I use the app without donating or receiving food?", "Yes, you can explore the app to learn about food donation opportunities, locate nearby donors, and browse educational content about reducing food waste. However, to actively participate, you need to register as a donor or receiver."),
            FaqItem("What should I do if I face issues with the app?", "If you encounter any issues, go to the 'Customer Care' section. You can either send us an email or call our support team. Describe the issue, and we’ll resolve it as quickly as possible."),
            FaqItem("Is this app available in multiple languages?", "Currently, the app is only available in English. However, we are working on adding support for regional and international languages to make the platform accessible to a broader audience."),
            FaqItem("How do I know the food I’m donating is being put to good use?", "The app ensures that your donations reach genuine, verified receivers. All transactions are recorded in the system for transparency, and you can track your impact through the 'History' section."),
            FaqItem("Can I donate food anonymously?", "Currently, you need to register to donate food for coordination purposes. However, your personal details are shared only with the receiver after they accept your donation."),
            FaqItem("What should I do if no one accepts my donation?", "If no one accepts your donation within a reasonable time, you can edit the listing or remove it. The app notifies you about the status of your donation, allowing you to decide whether to relist it or cancel."),
            FaqItem("How do I log out of the app?", "To log out, simply click on the 'Log Out' button on the dashboard. This will securely end your session and prevent unauthorized access to your account."),
            FaqItem("What if I forget to log out on a shared device?", "If you forget to log out from a shared device, you can change your password from another device. This action will automatically log you out of all active sessions, ensuring your account’s security."),

            )
    }

    private fun submitQuery() {
        val description = etQueryDescription.text.toString()
        val contactInfo = etContactInfo.text.toString()
        val contactMode = spContactMode.selectedItem.toString()

        if (description.isEmpty() || contactInfo.isEmpty()) {
            Toast.makeText(this, "Please fill all fields.", Toast.LENGTH_SHORT).show()
            return
        }

        if (contactMode == "Email" && !Patterns.EMAIL_ADDRESS.matcher(contactInfo).matches()) {
            Toast.makeText(this, "Invalid email address.", Toast.LENGTH_SHORT).show()
            return
        }

        if (contactMode == "Phone" && (contactInfo.length != 10 || !contactInfo.all { it.isDigit() })) {
            Toast.makeText(this, "Invalid phone number.", Toast.LENGTH_SHORT).show()
            return
        }

        val newQuery = PastQueryItem(description, contactInfo, resolved = false)
        pastQueries.add(newQuery)
        pastQueryAdapter.notifyItemInserted(pastQueries.size - 1)
        etQueryDescription.text.clear()
        etContactInfo.text.clear()
        spContactMode.setSelection(0)
        Toast.makeText(this, "Query submitted successfully!", Toast.LENGTH_SHORT).show()
    }

    private fun deleteAllQueries() {
        pastQueries.clear()
        pastQueryAdapter.notifyDataSetChanged()
        Toast.makeText(this, "All past queries deleted!", Toast.LENGTH_SHORT).show()
    }

    private fun handlePastQueryAction(action: String, position: Int) {
        when (action) {
            "RESOLVE" -> {
                pastQueries[position].resolved = true
                pastQueryAdapter.notifyItemChanged(position)
            }
            "DELETE" -> {
                pastQueries.removeAt(position)
                pastQueryAdapter.notifyItemRemoved(position)
            }
        }
    }
}
