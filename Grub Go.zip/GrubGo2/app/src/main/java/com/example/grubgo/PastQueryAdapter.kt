package com.example.grubgo.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.grubgo.R
import com.example.grubgo.models.PastQueryItem

class PastQueryAdapter(
    private val pastQueries: List<PastQueryItem>,
    private val onAction: (String, Int) -> Unit
) : RecyclerView.Adapter<PastQueryAdapter.PastQueryViewHolder>() {

    inner class PastQueryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvDescription: TextView = view.findViewById(R.id.tvDescription)
        val tvContactInfo: TextView = view.findViewById(R.id.tvContactInfo)
        val btnMarkResolved: Button = view.findViewById(R.id.btnMarkResolved)
        val btnDelete: Button = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PastQueryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_query, parent, false)
        return PastQueryViewHolder(view)
    }

    override fun onBindViewHolder(holder: PastQueryViewHolder, position: Int) {
        val query = pastQueries[position]
        holder.tvDescription.text = query.description
        holder.tvContactInfo.text = query.contactInfo

        if (query.resolved) {
            holder.btnMarkResolved.text = "Resolved"
            holder.btnMarkResolved.isEnabled = false
            holder.btnDelete.visibility = View.GONE
        } else {
            holder.btnMarkResolved.setOnClickListener {
                onAction("RESOLVE", position)
            }

            holder.btnDelete.setOnClickListener {
                onAction("DELETE", position)
            }
        }
    }

    override fun getItemCount(): Int = pastQueries.size
}
