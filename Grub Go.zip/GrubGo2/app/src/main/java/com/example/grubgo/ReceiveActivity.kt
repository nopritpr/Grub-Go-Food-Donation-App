package com.example.grubgo

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class ReceiveActivity : AppCompatActivity() {
    private lateinit var dbHelper: DBHelper
    private lateinit var spinner: Spinner
    private lateinit var imgFood1: ImageView
    private lateinit var imgFood2: ImageView
    private lateinit var imgFood3: ImageView
    private lateinit var tvExpiry: TextView
    private lateinit var tvWhenMade: TextView
    private lateinit var tvQuantity: TextView
    private lateinit var tvAddress: TextView
    private lateinit var tvDonorInfo: TextView
    private lateinit var btnSubmitRequest: Button

    private var selectedDonation: DBHelper.Donation? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.receive_layout)

        // Initialize DBHelper
        dbHelper = DBHelper.getInstance(this)

        // Initialize Views
        val etReceiverName = findViewById<EditText>(R.id.etReceiverName)
        val etReceiverContact = findViewById<EditText>(R.id.etReceiverContact)
        spinner = findViewById(R.id.spAvailableDonations)
        imgFood1 = findViewById(R.id.imgFood1)
        imgFood2 = findViewById(R.id.imgFood2)
        imgFood3 = findViewById(R.id.imgFood3)
        tvExpiry = findViewById(R.id.tvExpiry)
        tvWhenMade = findViewById(R.id.tvWhenMade)
        tvQuantity = findViewById(R.id.tvQuantity)
        tvAddress = findViewById(R.id.tvAddress)
        tvDonorInfo = findViewById(R.id.tvDonorInfo)
        btnSubmitRequest = findViewById(R.id.btnSubmitRequest)

        // Load available donations into the spinner
        loadAvailableDonations()

        // Handle spinner selection
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedFood = parent?.getItemAtPosition(position) as? String
                selectedDonation = dbHelper.getAvailableDonations().find { it.foodItem == selectedFood }
                updateUI(selectedDonation)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                selectedDonation = null
                clearUI()
            }
        }

        // Handle submit request
        btnSubmitRequest.setOnClickListener {
            val receiverName = etReceiverName.text.toString()
            val receiverContact = etReceiverContact.text.toString()

            if (receiverName.isBlank() || receiverContact.isBlank() || selectedDonation == null) {
                Toast.makeText(this, "Please fill all fields and select a donation!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Mark the donation as completed in the database
            selectedDonation?.id?.let { dbHelper.markAsCompleted(it) }

            // Display donor information
            tvDonorInfo.visibility = View.VISIBLE
            tvDonorInfo.text = "Donor: ${selectedDonation?.donorName}, Contact: ${selectedDonation?.contact}"

            // Reload donations to update the spinner
            loadAvailableDonations()
            clearUI()
        }
    }

    private fun loadAvailableDonations() {
        val donations = dbHelper.getAvailableDonations()
        val foodItems = donations.map { it.foodItem }.ifEmpty { listOf("No Donations Available") }

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, foodItems)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        // Clear selection if no donations are available
        if (donations.isEmpty()) {
            selectedDonation = null
            clearUI()
        }
    }

    private fun updateUI(donation: DBHelper.Donation?) {
        if (donation == null) {
            clearUI()
            return
        }

        // Load images
        val images = donation.imageUris
        Glide.with(this).load(images.getOrNull(0)).into(imgFood1)
        Glide.with(this).load(images.getOrNull(1)).into(imgFood2)
        Glide.with(this).load(images.getOrNull(2)).into(imgFood3)

        // Update details
        tvExpiry.text = "Expiry: ${donation.expiry}"
        tvWhenMade.text = "When Made: ${donation.whenMade}"
        tvQuantity.text = "Quantity: ${donation.quantity} ${donation.unit}"
        tvAddress.text = "Address: ${donation.address}"
    }

    private fun clearUI() {
        imgFood1.setImageResource(android.R.color.transparent)
        imgFood2.setImageResource(android.R.color.transparent)
        imgFood3.setImageResource(android.R.color.transparent)
        tvExpiry.text = "Expiry: N/A"
        tvWhenMade.text = "When Made: N/A"
        tvQuantity.text = "Quantity: N/A"
        tvAddress.text = "Address: N/A"
        tvDonorInfo.visibility = View.GONE
    }
}
