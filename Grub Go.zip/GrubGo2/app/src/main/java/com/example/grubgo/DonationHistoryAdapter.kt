package com.example.grubgo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class DonationHistoryAdapter(
    private val donationList: MutableList<DBHelper.Donation>
) : RecyclerView.Adapter<DonationHistoryAdapter.DonationViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DonationViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_history, parent, false)
        return DonationViewHolder(view)
    }

    override fun onBindViewHolder(holder: DonationViewHolder, position: Int) {
        val donation = donationList[position]
        holder.bind(donation)
    }

    override fun getItemCount(): Int = donationList.size

    fun addDonationAtTop(newDonation: DBHelper.Donation) {
        donationList.add(0, newDonation)
        notifyItemInserted(0)
    }

    fun clearDonations() {
        donationList.clear()
        notifyDataSetChanged()
    }

    class DonationViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imgFoodItem: ImageView = itemView.findViewById(R.id.imgFoodItem)
        private val tvFoodDetails: TextView = itemView.findViewById(R.id.tvFoodDetails)
        private val tvExpiry: TextView = itemView.findViewById(R.id.tvExpiry)
        private val tvWhenMade: TextView = itemView.findViewById(R.id.tvWhenMade)
        private val tvStatus: TextView = itemView.findViewById(R.id.tvStatus)

        fun bind(donation: DBHelper.Donation) {
            if (donation.imageUris.isNotEmpty() && donation.imageUris[0].isNotBlank()) {
                Glide.with(itemView.context)
                    .load(donation.imageUris[0])
                    .placeholder(R.drawable.item_background)
                    .into(imgFoodItem)
            } else {
                imgFoodItem.setImageResource(R.drawable.item_background)
            }

            tvFoodDetails.text = "Food Details: ${donation.foodItem}"
            tvExpiry.text = "Expiry: ${donation.expiry}"
            tvWhenMade.text = "When Made: ${donation.whenMade}"
            tvStatus.text = "Status: ${donation.status}"
        }
    }
}
